package birds;

public class Flightless extends Bird {
  public Flightless(String type, String characteristic, boolean isExtinct, int numWings, Food[] foods) {
    super(type, characteristic, isExtinct, numWings, foods);
  }
}
