package birds;

public class Shorebird extends Bird {
  public Shorebird(String type, String characteristic, Food[] foods) {
    super(type, characteristic, false, 2, foods);
  }
}
