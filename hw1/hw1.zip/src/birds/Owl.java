package birds;

public class Owl extends Bird {
  public Owl(String type, String characteristic, Food[] foods) {
    super(type, characteristic, false, 2, foods);
  }
}
