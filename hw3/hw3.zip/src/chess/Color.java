package chess;

public enum Color {
  black, white
}
