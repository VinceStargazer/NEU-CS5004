package cs5004.marblesolitaire.view;

import java.awt.*;

public class Colors {
  public static final Color green = new Color(73,177,77),
          bgGreen = new Color(45,129,37),
          beige = new Color(255,228,177),
          highlight = new Color(251, 203, 111),
          transparent = new Color(0, 0, 0, 0);
}
